%%generacion de Trayectorias de posici�n y velocidad y grafica posici�n y
%%velocidad
close all; clear all; clc;


addpath(genpath('D:\2014 - copiado\tesis de maestr�a'))% en genpah agrega todos los archivos 


q1i=-2;      % los valores  de los angulos iniciales y finales de las dos articulaciones 
q1f=2;       % estos valores son para probar las gr�ficas de las posiciones y velocidades
q2i=0;       % luego se har� una funci�n generador_02.m donde entre el vector definido de los q�s
q2f=1;
qi=[q1i q2i];
qf=[q1f q2f];

parametros_fisicos;  % esta es la parte de la rutina parametros_fisicos donde se definen las wmax
                     % wmax=[pi/10 pi/12];% maximas  velocidades de los
                     % actuadoressacadas de parametros_fisicos 
% calculo del tiempo
Tmax=max(abs((qf-qi)./wmax)); % calcula el tiempo maximo que tardar� todo el movimiento
w=(qf-qi)./Tmax;  % luego este Tmax me calcula la w (velocidad) de las dos articulaciones que ser�n vectores velocidades  
                  % recordar que Tmax es un escalar 
h=0.01; % es el paso de la iteraccion 
taux=0; % es el tiempo auxiliar 
i=1;
while taux<=Tmax      % Taux guarda el avance 
    q(:,i)=qi+w*taux; % es la ecuaci�n de q en este caso las dos, ac� cargamos el vector q1 y q2 con los valores de posici�n calculada
    Dq(:,i)=w;        % Dq es la velocidad (derivada de q) correspondiente a los dos desplazamiento de q1 y q2 que la sacamos de w que est� cargada 
    i=i+1;            % incremento el indice de uno en uno 
    taux=taux+h;      % incremento el paso de 0.01 en 0.01
end
                      % tener en cuaenta si los incrementos de h llegan a
                      % los valores que correspondan a q final es posible
                      % definir el while con el q para que llegue al q
                      % final
t=0:h:Tmax;
subplot(211);plot(t,q(1,:),t,q(2,:))   % recordar que 211 se va a dibiujar dos filas por una columna, dibujando en la primera fila 
subplot(212);plot(t,Dq(1,:),t,Dq(2,:)) % recordar que 211 se va a dibiujar dos filas por una columna, dibujando en la segunda fila
                                       % ploteando en x el t osea el tiempo
                                       % y en y las dos q o sea los
                                       % angulos 
                                       % en x el tiempo y en y las dos
                                       % velocidades
                                       
% en este caso las velocidades w son constantes en ambos casos   Dq(:,i)=w; , pero en
% general pueden variar 
