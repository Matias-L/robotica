%% Parametros Fisicos de pata primigenia
% se iran cargando los parametros fisicos del robot pata 
l1=3; % longitud del eslabon 1
l2=1.5; % longitud del eslabon 2

%% Actuadores
wmax=[pi/10 pi/12];% maximas  velocidades de los actuadores 